# Fixture skills

Two skills for the import tests.
