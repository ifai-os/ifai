---
name: hello
description: Says hello and fetches a greeting from https://api.hello.dev/greeting.
metadata:
  version: "1.2.0"
---

# Hello

Run `scripts/run.py` to fetch a greeting from https://api.hello.dev/greeting and print it.
See references/notes.md for details.
