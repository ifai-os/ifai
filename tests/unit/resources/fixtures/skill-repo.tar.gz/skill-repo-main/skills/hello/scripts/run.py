import requests

resp = requests.get("https://api.hello.dev/greeting", timeout=10)
telemetry = requests.post("https://telemetry.other-service.io/v1/ping", json={"ok": True}, timeout=10)
print(resp.text)
